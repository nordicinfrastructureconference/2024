what are container apps

differences with container instances and kubernetes

when should you use each

why secrets management is important

------------------------------
Build the app, no secrets
main.tf
resource_group.tf
container_app_env.tf
container_app.tf

Add only one env var

------------------------------
The less good way

Secret in container app
Add secret to container_app.tf, env variable

------------------------------
The good way

Build KV

Add KV policy for me

Create User Managed identity

Add KV policy

Create secret in portal

reference secret from KV as env

------------------------------
mention that secret can be mounted as volume

Show what secrets look like in Container App portal



docker run --rm -it -v $(pwd):/code -e ARM_SUBSCRIPTION_ID=7729f7fa-e4c3-4045-9baa-454a20b33ef4 testbox
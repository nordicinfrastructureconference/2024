
```bash
az deployment sub create --name assignment-demo-deployment  --template-file main.bicep -l westeurope
```
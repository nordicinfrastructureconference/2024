
```bash
az deployment sub create --name assignment-demo-with-parameter-deployment  --template-file main.bicep -l westeurope
```
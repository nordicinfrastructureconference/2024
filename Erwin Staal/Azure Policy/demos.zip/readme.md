# An introduction to Azure Policy
This repository contains a collection of Azure Policy definitions that can be used to enforce compliance within Azure. These policies are used in an introductionary session on Azure Policy.

The definitions are grouped into folders based on their category and each definition has a readme file that explains the purpose of the policy and how to deploy it.
USE PSPDemo
GO

-- Query Store queries
--SELECT sys.query_store_query.*
--FROM sys.query_store_query
--WHERE object_id = OBJECT_ID('dbo.OrdersGet')
--OR query_id IN (SELECT query_variant_query_id
--                FROM sys.query_store_query_variant
--                INNER JOIN sys.query_store_query ON sys.query_store_query_variant.parent_query_id = sys.query_store_query.query_id
--                WHERE object_id = OBJECT_ID('dbo.OrdersGet'))

-- Query Store texts
--SELECT sys.query_store_query_text.*
--FROM sys.query_store_query_text
--INNER JOIN sys.query_store_query ON sys.query_store_query_text.query_text_id = sys.query_store_query.query_text_id
--WHERE object_id = OBJECT_ID('dbo.OrdersGet')
--OR query_id IN (SELECT query_variant_query_id
--                FROM sys.query_store_query_variant
--                INNER JOIN sys.query_store_query ON sys.query_store_query_variant.parent_query_id = sys.query_store_query.query_id
--                WHERE object_id = OBJECT_ID('dbo.OrdersGet'))

-- Query Store plans
--SELECT sys.query_store_plan.*,
--       CAST(query_plan AS xml) AS query_plan_xml
--FROM sys.query_store_plan
--INNER JOIN sys.query_store_query ON sys.query_store_plan.query_id = sys.query_store_query.query_id
--WHERE object_id = OBJECT_ID('dbo.OrdersGet')
--OR sys.query_store_plan.query_id IN (SELECT query_variant_query_id
--                                     FROM sys.query_store_query_variant
--                                     INNER JOIN sys.query_store_query ON sys.query_store_query_variant.parent_query_id = sys.query_store_query.query_id
--                                     WHERE object_id = OBJECT_ID('dbo.OrdersGet'))

-- Query Store runtime statistics
SELECT *, CAST(query_plan AS xml) AS query_plan_xml
FROM sys.query_store_runtime_stats
INNER JOIN sys.query_store_plan ON sys.query_store_runtime_stats.plan_id = sys.query_store_plan.plan_id
INNER JOIN sys.query_store_query ON sys.query_store_plan.query_id = sys.query_store_query.query_id
WHERE object_id = OBJECT_ID('dbo.OrdersGet')
OR sys.query_store_plan.query_id IN (SELECT query_variant_query_id
                                     FROM sys.query_store_query_variant
                                     INNER JOIN sys.query_store_query ON sys.query_store_query_variant.parent_query_id = sys.query_store_query.query_id
                                     WHERE object_id = OBJECT_ID('dbo.OrdersGet'))

-- Query Store relations between query variants and parent queries
--SELECT *
--FROM sys.query_store_query_variant
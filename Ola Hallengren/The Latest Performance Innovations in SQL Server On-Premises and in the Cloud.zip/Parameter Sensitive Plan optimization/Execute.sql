USE PSPDemo
GO

-- Large number of orders
EXECUTE dbo.OrdersGet @CustomerID = 1
GO 1

-- Small number of orders
EXECUTE dbo.OrdersGet @CustomerID = 2
GO 100
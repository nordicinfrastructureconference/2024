USE PSPDemo
GO

DROP TABLE IF EXISTS dbo.Orders
GO

CREATE TABLE dbo.Orders (OrderID int PRIMARY KEY IDENTITY,
                         OrderDate datetime2,
                         CustomerID int)
GO

CREATE NONCLUSTERED INDEX IX_CustomerID ON dbo.Orders (CustomerID)
GO

INSERT INTO dbo.Orders (OrderDate, CustomerID)
SELECT SYSDATETIME() AS OrderDate,
       1 AS CustomerID
FROM GENERATE_SERIES(1, 999999)
GO

INSERT INTO dbo.Orders (OrderDate, CustomerID)
SELECT SYSDATETIME() AS OrderDate,
       2 AS CustomerID
FROM GENERATE_SERIES(1, 1)
GO

UPDATE STATISTICS dbo.Orders WITH FULLSCAN
GO

CREATE OR ALTER PROCEDURE dbo.OrdersGet

@CustomerID int

AS

SELECT *
FROM dbo.Orders
WHERE CustomerID = @CustomerID
GO

SELECT CustomerID, COUNT(*) AS NumberOfRows
FROM dbo.Orders
GROUP BY CustomerID

SELECT *
FROM sys.dm_db_stats_properties(OBJECT_ID('dbo.Orders'), 2)
GO

SELECT *
FROM sys.dm_db_stats_histogram(OBJECT_ID('dbo.Orders'), 2)
GO
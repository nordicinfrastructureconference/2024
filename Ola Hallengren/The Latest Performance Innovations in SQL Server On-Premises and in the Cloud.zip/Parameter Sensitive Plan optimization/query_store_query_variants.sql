USE PSPDemo
GO

SELECT *
FROM sys.query_store_query_variant
USE WideWorldImporters
GO

-- Look at Query Store hints
SELECT *
FROM sys.query_store_query_hints
GO
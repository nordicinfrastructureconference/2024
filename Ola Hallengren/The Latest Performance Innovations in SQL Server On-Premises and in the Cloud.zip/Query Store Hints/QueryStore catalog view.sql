USE WideWorldImporters
GO

-- Look at Query Store runtime statistics
SELECT sys.query_store_query.query_id,
       sys.query_store_query.query_text_id,
       sys.query_store_query_text.query_sql_text,
       sys.query_store_plan.plan_id,
       CAST(sys.query_store_plan.query_plan AS xml) AS query_plan,
       sys.query_store_runtime_stats.*
FROM sys.query_store_runtime_stats
INNER JOIN sys.query_store_plan ON sys.query_store_runtime_stats.plan_id = sys.query_store_plan.plan_id
INNER JOIN sys.query_store_query ON sys.query_store_plan.query_id = sys.query_store_query.query_id
INNER JOIN sys.query_store_query_text ON sys.query_store_query.query_text_id = sys.query_store_query_text.query_text_id
WHERE sys.query_store_query_text.query_sql_text LIKE '%SELECT * FROM Sales.Orders WHERE CustomerID = @CustomerID%'
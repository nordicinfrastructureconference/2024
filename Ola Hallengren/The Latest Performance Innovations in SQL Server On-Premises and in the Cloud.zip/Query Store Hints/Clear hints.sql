USE WideWorldImporters
GO

-- Clear hints for a query in Query Store
EXECUTE sp_query_store_clear_hints @query_id = 2
GO
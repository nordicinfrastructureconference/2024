USE WideWorldImporters
GO

-- Set hints for a query in Query Store
EXECUTE sys.sp_query_store_set_hints @query_id = 21, @query_hints = N'OPTION(RECOMPILE)'
GO
USE WideWorldImporters
GO

-- Select all orders for a customer 

DECLARE @CustomerID int  
DECLARE @SQLString nvarchar(4000)
DECLARE @ParameterDefinition nvarchar(4000)

SET @SQLString = N'SELECT * FROM Sales.Orders WHERE CustomerID = @CustomerID';  
SET @ParameterDefinition = N'@CustomerID int';  
  
EXECUTE sp_executesql @SQLString, @ParameterDefinition, @CustomerID = 1059
GO 50


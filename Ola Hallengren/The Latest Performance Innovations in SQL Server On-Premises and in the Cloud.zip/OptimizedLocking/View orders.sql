
-- View all orders by OrderDate
SELECT OrderDate, COUNT(*) AS NumberOfOrders
FROM [dbo].[Orders]
GROUP BY OrderDate
ORDER BY OrderDate
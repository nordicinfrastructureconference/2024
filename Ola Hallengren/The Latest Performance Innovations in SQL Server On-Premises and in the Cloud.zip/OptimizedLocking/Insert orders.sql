
TRUNCATE TABLE dbo.Orders

INSERT INTO dbo.Orders (OrderDate, CustomerID)
SELECT DATEADD(DAY, NTILE(10) OVER(ORDER BY [value]) - 1, '2024-01-01') AS OrderDate,
       1 AS CustomerID
FROM GENERATE_SERIES(1, 10000000)
GO
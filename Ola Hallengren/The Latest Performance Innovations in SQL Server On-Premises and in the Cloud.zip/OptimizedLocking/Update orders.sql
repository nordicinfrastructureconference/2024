
-- Update all orders for one day (1000000 rows)
UPDATE [dbo].[Orders]
SET Comment = 'Test'
WHERE OrderDate = '2024-01-01'
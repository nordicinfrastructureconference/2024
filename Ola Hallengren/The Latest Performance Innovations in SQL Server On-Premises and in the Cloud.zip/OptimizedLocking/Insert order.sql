SET STATISTICS TIME ON

-- Insert a single order
INSERT INTO dbo.Orders (OrderDate)
SELECT '2024-01-11' AS OrderDate
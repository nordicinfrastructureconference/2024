
SELECT name,
       is_accelerated_database_recovery_on
FROM sys.databases
WHERE name IN('ADRDemo01', 'ADRDemo02')
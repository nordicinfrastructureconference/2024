-- This database does not have ADR enabled
USE ADRDemo01
GO
ALTER TABLE dbo.Orders ALTER COLUMN CustomerID bigint NOT NULL
GO
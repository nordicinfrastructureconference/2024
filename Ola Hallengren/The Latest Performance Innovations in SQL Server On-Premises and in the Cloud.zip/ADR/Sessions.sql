
SELECT sys.dm_exec_sessions.session_id,
       DB_NAME(sys.dm_exec_sessions.database_id) AS database_name,
       sys.dm_exec_requests.total_elapsed_time,
	   sys.dm_exec_requests.command
FROM sys.dm_exec_sessions
INNER JOIN sys.dm_exec_requests ON sys.dm_exec_sessions.session_id = sys.dm_exec_requests.session_id
WHERE login_name = 'Ola\Ola Hallengren'
AND sys.dm_exec_sessions.session_id <> @@SPID
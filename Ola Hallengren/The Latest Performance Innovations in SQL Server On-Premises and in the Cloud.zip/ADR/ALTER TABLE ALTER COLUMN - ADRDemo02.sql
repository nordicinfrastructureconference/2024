-- This database has ADR enabled
USE ADRDemo02
GO
ALTER TABLE dbo.Orders ALTER COLUMN CustomerID bigint NOT NULL
GO